<?php

// APIs
const ADDRESS_API_URL = "http://discover.konjungate.net/ext/getaddress/";
const TRANSACTION_API_URL = "http://discover.konjungate.net/api/getrawtransaction";
const PRICE_API_URL = "https://api.crex24.com/v2/public/tickers?instrument=KONJ-BTC";
const BITCOIN_PRICE_API_URL = "https://api.coingecko.com/api/v3/coins/bitcoin?localization=false";

// Messages
const WAITING_MSG = "Waiting for payment...";
const CONFIRMED_MSG = "Transaction successfully confirmed.";


// get the HTTP method
$method = $_SERVER['REQUEST_METHOD'];

if ($method = "GET") {

    if (isset($_GET['rate'])) { // Get information about price rate for passed currency

        $default_currency = strtolower($_GET['rate']);

        // Get btc price
        $url = file_get_contents(PRICE_API_URL);
        $result = json_decode($url, true);

        // Get default currency / btc price
        $url2 = file_get_contents(BITCOIN_PRICE_API_URL);
        $result2 = json_decode($url2);


        if(!empty($result))
        {
            $rateKONJ = $result[0]["last"];
            $rateBTC = $result2->market_data->current_price->$default_currency;

            $rate = $rateKONJ * $rateBTC;

            echo json_encode($rate);
            exit;
        }
    }
    else if (isset($_GET['address'])){ // Get information about address and transaction
        $payment_address = $_GET['address'];
        $payment_amount = filter_var($_GET['amount'], FILTER_SANITIZE_NUMBER_FLOAT,FILTER_FLAG_ALLOW_FRACTION);
        $order_transaction = $_GET['tx'];
        $order_time = $_GET['otime'];
        $min_confirmations = $_GET['conf'];
        $max_time_limit = $_GET['mtime'];
        $plugin_version = $_GET['pv'];


        // Check if all parameters are provided
        if (!$payment_address || !$payment_amount || !$order_transaction || !$order_time || !$min_confirmations || !$max_time_limit) {
            echo json_encode(['status' => 'invalid']);
            exit;
        }

        if($order_transaction != "missing") { // Verify transaction, assumably if payment is detected and tx provided

            $url = file_get_contents(TRANSACTION_API_URL ."?txid=" . $order_transaction ."&decrypt=1");
            $result = json_decode($url, true);
            $tx_status = 0;

            if(!empty($result)) {

                // Check if result is valid
                if(!$result['vout']) {
                    send_json(['status' => "invalid", 'message' => "Invalid 1"]);
                    exit;
                }

                // Validate time of order
                if($result['time'] < $order_time) {
                    send_json(['status' => "invalid", 'message' => "Invalid 2"]);
                    exit;
                }

                // Validate address and amount of transaction
                foreach ($result['vout'] as $vout) {
                    $vout_value = $vout['value'];
                    $current_address = $vout['scriptPubKey']['addresses'][0];

                    if ($payment_address == $current_address) {
                        if($payment_amount == $vout_value) {
                            $tx_status = 1;
                        }
                    }
                }

                // If all previous transaction validations are valid, proceed to the validation of confirmations
                if ($tx_status == 1) {
                    if($result['confirmations'] >= $min_confirmations) {
                        send_json(['status' => "confirmed", 'message' => CONFIRMED_MSG, 'transaction_id' => $order_transaction, 'confirmations' => $result['confirmations']]);
                        exit;
                    }
                    else {
                        send_json(['status' => "detected", 'message' => 'Transaction detected. Waiting for confirmations - ' . $result['confirmations'] ."/" . $min_confirmations, 'transaction_id' => $order_transaction, 'confirmations' => $result['confirmations']]);
                        exit;
                    }
                }
                else {
                    send_json(['status' => "invalid", 'message' => "Invalid 3"]);
                    exit;
                }
            }
            else {
                send_json(["status" => "failed"]);
                exit;
            }
        }
        else { // Verify address and transaction

            $detected = 0;
            $detected_transaction = "missing";

            $payment_address = $_GET['address'];
            $url = file_get_contents(ADDRESS_API_URL . $payment_address);
            $result = json_decode($url, true);

            if(!empty($result)) {

                foreach (array_reverse($result["last_txs"]) as $tx) {
                    $tested_trx = $tx["addresses"];
                    $url = file_get_contents(TRANSACTION_API_URL ."?txid=" . $tested_trx ."&decrypt=1");
                    $result = json_decode($url, true);

                    // Validate time of order
                    if($result['time'] > $order_time) { // Check if transaction time is not older than order time

                        // Validate address and amount of transaction
                        foreach ($result['vout'] as $vout) {
                            $vout_value = $vout['value'];
                            $current_address = $vout['scriptPubKey']['addresses'][0];


                            if ($payment_address == $current_address) {
                                if($payment_amount == $vout_value) {

                                    $detected = 1;
                                    $detected_transaction = $tested_trx;

                                    if($result['confirmations'] >= $min_confirmations) {
                                        send_json(['status' => "confirmed", 'message' => 'Transaction successfully confirmed.', 'transaction_id' => $detected_transaction, 'confirmations' => $result['confirmations']]);
                                        break;
                                    }
                                    else {
                                        send_json(['status' => "detected", 'message' => 'Transaction detected. Waiting for confirmations - ' . $result['confirmations'] ."/" . $min_confirmations, 'transaction_id' => $detected_transaction, 'confirmations' => $result['confirmations']]);
                                    }
                                }
                            }
                        }
                    }
                }

                if ($detected == 0) {
                    send_json(['status' => "waiting", 'message' => WAITING_MSG]);
                    exit;
                }
            }
        }
    }
    else {
        send_json("Invalid request");
    }
    die;
}
else {
    send_json("Invalid request");
}



// Prepare json fon sending
function send_json($resp, $status=200) {
    header('Content-type: application/json; charset=utf-8');

    if ( $status ) { // status code
        http_response_code($status);
    }

    print json_encode($resp);
    die;
}
